import { useState, useEffect } from "react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { motion } from "framer-motion";
import Link from "next/link";

export default function CheckoutPage() {
  const [form, setForm] = useState({ name: "", phone: "", address: "" });
  const [submitted, setSubmitted] = useState(false);
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    const storedCart = localStorage.getItem("cart");
    if (storedCart) {
      setCartItems(JSON.parse(storedCart));
    }
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    const order = { ...form, cart: cartItems };
    localStorage.setItem("lastOrder", JSON.stringify(order));
    setSubmitted(true);
    localStorage.removeItem("cart");
  };

  const total = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);

  return (
    <div className="min-h-screen bg-orange-50 py-8 px-4">
      <div className="max-w-xl mx-auto">
        <h1 className="text-3xl font-bold text-orange-800 text-center mb-6">
          Checkout
        </h1>

        {submitted ? (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-green-100 text-green-800 p-4 rounded-xl text-center"
          >
            ✅ Order placed successfully! Thank you, {form.name}.
          </motion.div>
        ) : (
          <>
            {cartItems.length > 0 ? (
              <Card className="border-orange-300 mb-6">
                <CardContent className="p-4">
                  <h2 className="text-lg font-bold text-orange-700 mb-2">Your Cart</h2>
                  <ul className="space-y-2 text-gray-700">
                    {cartItems.map((item, index) => (
                      <li key={index} className="flex justify-between">
                        <span>{item.name} x {item.quantity}</span>
                        <span>₹{item.price * item.quantity}</span>
                      </li>
                    ))}
                  </ul>
                  <hr className="my-3" />
                  <p className="text-right font-bold text-orange-800">Total: ₹{total}</p>
                </CardContent>
              </Card>
            ) : (
              <p className="text-center text-gray-500 mb-4">🛒 Your cart is empty.</p>
            )}

            <Card className="border-orange-300">
              <CardContent className="p-6 space-y-4">
                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-orange-700 font-semibold">Full Name</label>
                    <Input name="name" value={form.name} onChange={handleChange} required />
                  </div>
                  <div>
                    <label className="block text-orange-700 font-semibold">Phone Number</label>
                    <Input name="phone" value={form.phone} onChange={handleChange} required type="tel" />
                  </div>
                  <div>
                    <label className="block text-orange-700 font-semibold">Delivery Address</label>
                    <Input name="address" value={form.address} onChange={handleChange} required />
                  </div>
                  <Button type="submit" className="bg-orange-600 text-white w-full">
                    Confirm Order
                  </Button>
                </form>
              </CardContent>
            </Card>
          </>
        )}

        <Link href="/">
          <p className="text-center text-orange-600 mt-6 underline">← Back to Home</p>
        </Link>
      </div>
    </div>
  );
}
